#!/bin/bash
# Automated Project 2

./b3z8 insert10000.txt 100 data -mys01 -mys02 -mys03 -mys04 -mys05 -mys06 -mys07;

rm -rf /data/*.dat;
find ./data -type f -not -name "*.*" -exec mv "{}" "{}".dat \;

matlab -nodesktop -nosplash -r "run('data/plt')";
