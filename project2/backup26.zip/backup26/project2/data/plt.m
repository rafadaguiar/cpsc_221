files = dir('*.dat');
figure('visible','off');
for i=1:length(files)
	f=files(i);
	data = importdata(f.name);
	x = data(:,1);
	y = data(:,2);
	title(f.name);
	plot(x,y);
	saveas(gcf,fullfile(pwd,'/output/',strcat(f.name,'.jpg')),'jpg');
end
disp('Successful plot!');
exit;
